#!/bin/bash

set -e

# Constants
REPO_URL="https://github.com/srikanth37/ren3-debian-vm-ansible.git"
CLONE_DIR="ren3-debian-vm-ansible"
CONFIG_FILE="config.json"

echo "Checking prerequisites..."

# Update package list
sudo apt update

# Ensure Python 3
if ! command -v python3 &> /dev/null; then
    echo "Installing Python3..."
    sudo apt install -y python3
else
    echo "Python3 is already installed."
fi

# Ensure pip3
if ! command -v pip3 &> /dev/null; then
    echo "Installing pip3..."
    sudo apt install -y python3-pip
else
    echo "pip3 is already installed."
fi

# Ensure Ansible
if ! command -v ansible &> /dev/null; then
    echo "Installing Ansible..."
    sudo apt install -y ansible
else
    echo "Ansible is already installed."
fi

# Ensure Git
if ! command -v git &> /dev/null; then
    echo "Installing Git..."
    sudo apt install -y git
else
    echo "Git is already installed."
fi

# Ensure jq
if ! command -v jq &> /dev/null; then
    echo "jq not found. Installing..."
    sudo apt install -y jq
else
    echo "jq is already installed."
fi

# Clone the Ansible repo
if [ -d "$CLONE_DIR" ]; then
    echo "Directory $CLONE_DIR already exists. Removing..."
    rm -rf "$CLONE_DIR"
fi

echo "Cloning Ansible repo..."
git clone "$REPO_URL" "$CLONE_DIR"

# Copy SSL certs
echo "Copying SSL files to the Ansible repo..."
cp ren3ssl.crt "$CLONE_DIR"/roles/nginx/templates/
cp ren3ssl.key "$CLONE_DIR"/roles/nginx/templates/

cd "$CLONE_DIR"

# Inject values from config.json
echo "Updating group_vars with values from $CONFIG_FILE..."

update_var() {
    local key=$1
    local value=$(jq -r ".$key" "../$CONFIG_FILE")
    safe_value=$(printf '%s\n' "$value" | sed 's/[\/&]/\\&/g')
    sed -i.bak "s/${key}_placeholder/$safe_value/g" inventories/production/group_vars/all.yml
}

update_var "app_user"
update_var "app_group"
update_var "app_home"
update_var "app_server_url"
update_var "dotnet_version"
update_var "dotnet_dir"
update_var "node_version"
update_var "qdrant_storage_dir"
update_var "qdrant_host"
update_var "react_app_backend_url"
update_var "react_app_portal_url"
update_var "ingestor_url"
update_var "server_url"
update_var "ej2apiservices_url"
update_var "frontend_server_name"
update_var "backend_server_name"
update_var "grafana_server_name"
update_var "mariadb_root_password"
update_var "db_hostname"
update_var "license_key"
update_var "squadcast_url"

# Handle array: mariadb_databases
echo "Updating mariadb_databases array..."
database_name=$(jq -r '.mariadb_databases[0].name' ../$CONFIG_FILE)
sed -i.bak "s/mariadb_database_name_placeholder/${database_name}/g" inventories/production/group_vars/all.yml

# Run Ansible playbook
echo "Running Ansible playbook..."
ansible-playbook -i inventory.ini playbooks/site.yml